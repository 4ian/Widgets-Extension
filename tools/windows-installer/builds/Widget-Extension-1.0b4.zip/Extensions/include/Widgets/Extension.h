/*
Widgets Extension
Extension providing graphical widgets.
*/

#ifndef WIDGETMAIN_H
#define WIDGETMAIN_H

#include "GDL/ExtensionBase.h"
#include "GDL/Version.h"
#include "textbox/TextAreaObject.h"
#include "button/ButtonObject.h"
#include "checkbox/CheckBoxObject.h"
#include "scale/ScaleObject.h"
#include "Manager.h"
#include "GDResourceLoader.h"
#include "SFGUI/Context.hpp"
#include "SFGUI/Engine.hpp"

#include <boost/version.hpp>

///Widgets Extension (WE) Version
#define WE_VERSION std::string("1.0b3")
#define SFGUI_VERSION std::string("git 15/10/2011")

/**
 * This class declare information about the extension.
 */
class Extension : public ExtensionBase
{
    public:

        /**
         * Constructor of an extension declares everything the extension contains : Objects, actions, conditions and expressions.
         */
        Extension();

        virtual ~Extension() {};

    protected:
    private:

        /**
         * This function is called by Game Develop so
         * as to complete information about how the extension was compiled ( which libs... )
         * -- Do not need to be modified. --
         */
        void CompleteCompilationInformation();

        void DeclareTextBox();
        void DeclareButton();
        void DeclareScale();
        void DeclareCheckBox();
};

/**
 * Used by Game Develop to create the extension class
 * -- Do not need to be modified. --
 */
extern "C" ExtensionBase * GD_EXTENSION_API CreateGDExtension();

/**
 * Used by Game Develop to destroy the extension class
 * -- Do not need to be modified. --
 */
extern "C" void GD_EXTENSION_API DestroyGDExtension(ExtensionBase * p);
#endif

