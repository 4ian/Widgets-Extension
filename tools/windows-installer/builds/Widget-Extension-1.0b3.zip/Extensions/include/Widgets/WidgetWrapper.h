#ifndef WIDGETWRAPPER_H
#define WIDGETWRAPPER_H

#include <memory>

#include "SFGUI/Scale.hpp"
#include "SFGUI/Entry.hpp"
#include "SFGUI/Button.hpp"


/**
 * WidgetWrapper allows the extension to use C++0x functionnalities (std::shared_ptr) inside Game Develop without "say" it to its internal compilator.
**/
template<class T>
class WidgetWrapper
{
    public:
        WidgetWrapper(std::shared_ptr<T>&);

        /**
         * Get the smart pointer
        **/
        std::shared_ptr<T>& Get() {return obj;};

    private:
        std::shared_ptr<T> obj; ///< smart pointer stored
};

template<class T>
WidgetWrapper<T>::WidgetWrapper(std::shared_ptr<T> &object)
{
    obj = object;
}

#endif
