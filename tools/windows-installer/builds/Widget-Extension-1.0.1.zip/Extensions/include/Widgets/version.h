///Widgets Extension (WE) Version
#define WE_VERSION std::string("1.0.1")
#define SFGUI_VERSION std::string("git 12/12/2011 beta")
